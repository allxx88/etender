---
title: '2023年VR游戏周即将到来！'
date: '2022-12-27T13:06:38+08:00'
description: 'Vr Games Week 2023 Starts Next Week'
author: '虚幻引擎官网'
cover: 'https://cdn2.unrealengine.com/vr-week-2023-header-4-1920x1080-376e6c48383f.jpg?resize=1&w=1920'
tags: ["功能", "动画", "广播与实况", "虚幻引擎"]
theme: 'light'
---

PlayStation VR2即将于下周发布。为表庆祝，我们准备介绍数部即将登陆此平台的虚幻引擎VR游戏，以及一些准备登陆Meta Quest、PCVR等平台的虚幻VR作品。

![PS|inline](https://cdn2.unrealengine.com/vr-week-2023-header-4-1920x1080-376e6c48383f.jpg?resize=1&w=1920)

2023年VR游戏周将从2月21日（周二）一直持续到2月25日（周六）。届时，我们将向大家介绍一系列优秀的VR游戏案例，并推介以下项目：
《Hubris》
《黑相集：之字路VR》
《行尸走肉：圣徒与罪人第二章》
《穿越火线：塞拉小队》
一期以VR为主题的Inside Unreal直播
一款尚未公布的VR游戏
还有更多精彩内容等你来发现！

欲了解最新消息，请收藏我们的VR游戏周活动页面.